import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Editor from './pages/Editor';
import Export from './pages/Export';
import FlowFarm from './pages/FlowFarm';
import FlowFarmForest from './pages/FlowFarmForest';
import FlowFarmGallery from './pages/FlowFarmGallery';
import FlowFarmHome from './pages/FlowFarmHome';
import Gallery from './pages/Gallery';
import GarrenHillGallery from './pages/GarrenHillGallery';
import Home from './pages/Home';
import Import from './pages/Import';
import Index from './pages/Index';
import Media from './pages/Media';
import Review from './pages/Review';
import SocialPost from './pages/SocialPost';
import FlowFarmLanding from './pages/FlowFarmLanding';
import MLS from './pages/MLS';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/Home" replace />} />
        <Route path="/Editor" element={<Editor />} />
        <Route path="/Export" element={<Export />} />
        <Route path="/FlowFarm" element={<FlowFarm />} />
        <Route path="/FlowFarmForest" element={<FlowFarmForest />} />
        <Route path="/FlowFarmGallery" element={<FlowFarmGallery />} />
        <Route path="/FlowFarmHome" element={<FlowFarmHome />} />
        <Route path="/Gallery" element={<Gallery />} />
        <Route path="/GarrenHillGallery" element={<GarrenHillGallery />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/Import" element={<Import />} />
        <Route path="/Index" element={<Index />} />
        <Route path="/Media" element={<Media />} />
        <Route path="/Review" element={<Review />} />
        <Route path="/SocialPost" element={<SocialPost />} />
        <Route path="/FlowFarmLanding" element={<FlowFarmLanding />} />
        <Route path="/MLS" element={<MLS />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
